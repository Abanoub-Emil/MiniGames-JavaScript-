# JavaScript-Games

-Please Use firefox browser 

It's a page that contains 4 games 
User can choose which one he wants to play.

1-Bejeweled Game

How to play bejeweled game

-The player has 60 seconds to collect as he/she can get points by collecting 4 successive candies with the same 
type in same row or column.

//////////////////////////////////////////////////////////////////////////////////////////////////

2-Shape Attack Game
              
How to play Shape attack game

-Use your mouse to select any shape from the different shapes' buttons to change your shape 
according to the shape falling from the top side.

-For each correct match between your shape and the falling shape you gain a point and sometimes you get 
a jewel with 5 points but if you fail to match the two shapes you lose. 

//////////////////////////////////////////////////////////////////////////////////////////////////

3-Connect Four Game

How to play Connect 4 game

1 - Enter player 1 name and player 2 name under the color that you are going to play with. 
ex: Player 1 : (Abanoub). if you don't need to enter your name you can let it empty and play using color.

2 - Click start game to go the game page.

3- try to connect 4 successive circles vertically or horizontally or diagonally 
from the same color to win.

///////////////////////////////////////////////////////////////////////////////////////////////////

4-Sudoku Game
 
Sudoku (2*2) is a puzzle number game that contains 4 rows, 4 columns and 4 squares.

The rules of the game:

1- Each row and each column contains only 4 numbers from 1 to 4 without repetition.
2- Each square also contains only 4 numbers from 1 to 4 without repetition.

There are 3 Levels of the game (Easy, Medium and Hard).

The Numbers are auto generated at each game "No Saved Templates" and the places of empty cells are also auto changed each game.

You can check your answer whether it is true or false and also you can solve the problem.
